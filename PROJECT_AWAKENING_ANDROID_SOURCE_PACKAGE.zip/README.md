# PROJECT: AWAKENING — Android APK

Ce projet Android embarque le jeu dans une WebView locale. Aucune connexion
Internet n'est nécessaire pendant l'utilisation. La progression reste dans
le stockage local de l'application. L'import/export de sauvegarde JSON utilise
le sélecteur de fichiers Android.

## Build sur un PC avec Android SDK
- JDK 17
- Android SDK Platform 35
- Gradle 8.9
- Commande : `gradle assembleDebug`
- APK : `app/build/outputs/apk/debug/app-debug.apk`

## Build depuis un téléphone avec GitHub Actions
Il n'est pas nécessaire d'avoir Android Studio sur le téléphone.

1. Extraire `PROJECT_AWAKENING_ANDROID_SOURCE_PACKAGE.zip` avec l'application Fichiers.
2. Créer un dépôt GitHub **privé**.
3. Dans le dépôt, téléverser le fichier `project-awakening-source.zip` à la racine.
4. Dans GitHub, choisir **Add file > Create new file**.
5. Nom du fichier : `.github/workflows/build-apk.yml`
6. Copier le contenu du fichier `build-apk.yml` fourni dans le package, puis valider le commit.
7. Ouvrir l'onglet **Actions** > **Build PROJECT AWAKENING APK** > **Run workflow**.
8. Quand le workflow est terminé, ouvrir son exécution et télécharger l'artifact
   `PROJECT-AWAKENING-debug-apk`.
9. Extraire l'artifact ZIP, puis installer `app-debug.apk` sur le Samsung.

## Sécurité et sauvegarde
- Le dépôt GitHub peut rester privé.
- L'application n'a pas besoin de permission Internet au runtime.
- Exporter régulièrement une sauvegarde depuis Planning.
- Ne pas désinstaller l'application avant d'avoir exporté la sauvegarde :
  Android peut effacer ses données locales lors de la désinstallation.
